package com.g2appdev.sinesugbowatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SinesugbowatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(SinesugbowatchApplication.class, args);
	}

}
