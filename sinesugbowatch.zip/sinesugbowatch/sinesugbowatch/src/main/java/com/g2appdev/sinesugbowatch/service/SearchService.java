package com.g2appdev.sinesugbowatch.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.g2appdev.sinesugbowatch.entity.Search;
import com.g2appdev.sinesugbowatch.repository.SearchRepository;

@Service
public class SearchService {

    @Autowired
    SearchRepository searchRepository;

    public Search postSearchRecord(Search search) {
        return searchRepository.save(search);
    }

    public List<Search> getAllSearches() {
        return searchRepository.findAll();
    }

    public Search putSearchDetails(int id, Search newSearchDetails) {
        Search existingSearch = searchRepository.findById(id).orElse(null);
        if (existingSearch != null) {
            existingSearch.setSearchquery(newSearchDetails.getSearchquery());
            existingSearch.setSearchdate(newSearchDetails.getSearchdate());
            existingSearch.setUser_id(newSearchDetails.getUser_id());
            return searchRepository.save(existingSearch);
        }
        return null;
    }

    public String deleteSearch(int id) {
        if (searchRepository.existsById(id)) {
            searchRepository.deleteById(id);
            return "Search record deleted successfully.";
        }
        return "Search record not found.";
    }
}
