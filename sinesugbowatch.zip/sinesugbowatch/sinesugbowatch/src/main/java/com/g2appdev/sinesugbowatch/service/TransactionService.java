package com.g2appdev.sinesugbowatch.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.g2appdev.sinesugbowatch.entity.Transaction;
import com.g2appdev.sinesugbowatch.repository.TransactionRepository;

@Service
public class TransactionService {

    @Autowired
    TransactionRepository transactionRepository;

    public Transaction postTransactionRecord(Transaction transaction) {
        return transactionRepository.save(transaction);
    }

    public List<Transaction> getAllTransactions() {
        return transactionRepository.findAll();
    }

    public Transaction putTransactionDetails(int id, Transaction newTransactionDetails) {
        Transaction existingTransaction = transactionRepository.findById(id).orElse(null);
        if (existingTransaction != null) {
            existingTransaction.setPaymentmethod(newTransactionDetails.getPaymentmethod());
            existingTransaction.setUser_id(newTransactionDetails.getUser_id());
            existingTransaction.setMovie_id(newTransactionDetails.getMovie_id());
            return transactionRepository.save(existingTransaction);
        }
        return null;
    }

    public String deleteTransaction(int id) {
        if (transactionRepository.existsById(id)) {
            transactionRepository.deleteById(id);
            return "Transaction record deleted successfully.";
        }
        return "Transaction record not found.";
    }
}
