package com.g2appdev.sinesugbowatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SinesugbowatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
